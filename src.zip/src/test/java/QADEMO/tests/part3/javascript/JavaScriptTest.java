package QADEMO.tests.part3.javascript;

import org.junit.jupiter.api.Test;
import QADEMO.Base.BaseTest_QADEMO;

public class JavaScriptTest extends BaseTest_QADEMO {

    @Test
    public void scroolAndClickForms() {

        homePage.goToFormsPage();
    }
}

